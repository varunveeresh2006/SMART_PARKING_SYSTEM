import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
      { auth: { autoRefreshToken: false, persistSession: false } }
    );

    const results: Record<string, string> = {};

    // Create demo user
    const { data: demoData, error: demoError } = await supabase.auth.admin.createUser({
      email: "demo@orionmall.com",
      password: "Demo@1234",
      email_confirm: true,
      user_metadata: { full_name: "Demo User" },
    });

    if (demoError && !demoError.message.includes("already been registered")) {
      results.demo = `Error: ${demoError.message}`;
    } else if (demoData?.user) {
      // Upsert profile
      await supabase.from("user_profiles").upsert({
        id: demoData.user.id,
        full_name: "Demo User",
        phone: "9876543210",
        role: "user",
      }, { onConflict: "id" });
      results.demo = "created";
    } else {
      results.demo = "already exists";
    }

    // Create admin user
    const { data: adminData, error: adminError } = await supabase.auth.admin.createUser({
      email: "admin@orionmall.com",
      password: "Admin@1234",
      email_confirm: true,
      user_metadata: { full_name: "Admin User" },
      app_metadata: { role: "admin" },
    });

    if (adminError && !adminError.message.includes("already been registered")) {
      results.admin = `Error: ${adminError.message}`;
    } else if (adminData?.user) {
      await supabase.from("user_profiles").upsert({
        id: adminData.user.id,
        full_name: "Admin User",
        phone: "9876543211",
        role: "admin",
      }, { onConflict: "id" });
      results.admin = "created";
    } else {
      results.admin = "already exists";
    }

    // If users already existed, find and update their profiles
    if (results.demo === "already exists") {
      const { data: existingDemo } = await supabase.auth.admin.listUsers();
      const demoUser = existingDemo?.users?.find(u => u.email === "demo@orionmall.com");
      if (demoUser) {
        await supabase.from("user_profiles").upsert({
          id: demoUser.id,
          full_name: "Demo User",
          phone: "9876543210",
          role: "user",
        }, { onConflict: "id" });
        results.demo = "profile updated";
      }
    }

    if (results.admin === "already exists") {
      const { data: existingUsers } = await supabase.auth.admin.listUsers();
      const adminUser = existingUsers?.users?.find(u => u.email === "admin@orionmall.com");
      if (adminUser) {
        await supabase.auth.admin.updateUserById(adminUser.id, {
          app_metadata: { role: "admin" },
        });
        await supabase.from("user_profiles").upsert({
          id: adminUser.id,
          full_name: "Admin User",
          phone: "9876543211",
          role: "admin",
        }, { onConflict: "id" });
        results.admin = "profile updated";
      }
    }

    return new Response(JSON.stringify({ success: true, results }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ success: false, error: String(err) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

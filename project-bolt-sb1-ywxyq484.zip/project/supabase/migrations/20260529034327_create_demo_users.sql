/*
  # Create Demo User Accounts

  Creates two demo accounts for testing:
  1. Regular user: demo@orionmall.com / Demo@1234
  2. Admin user: admin@orionmall.com / Admin@1234

  Note: Admin profile is set via user_profiles.role = 'admin'
*/

-- Insert demo user into auth.users (Supabase approach)
-- We use a function to safely create users if they don't exist
DO $$
DECLARE
  demo_user_id uuid;
  admin_user_id uuid;
BEGIN
  -- Check if demo user exists
  SELECT id INTO demo_user_id FROM auth.users WHERE email = 'demo@orionmall.com';
  IF demo_user_id IS NULL THEN
    INSERT INTO auth.users (
      instance_id, id, aud, role, email,
      encrypted_password, email_confirmed_at,
      raw_app_meta_data, raw_user_meta_data,
      created_at, updated_at, confirmation_token, recovery_token
    ) VALUES (
      '00000000-0000-0000-0000-000000000000',
      gen_random_uuid(), 'authenticated', 'authenticated',
      'demo@orionmall.com',
      crypt('Demo@1234', gen_salt('bf')),
      now(),
      '{"provider": "email", "providers": ["email"]}',
      '{"full_name": "Demo User"}',
      now(), now(), '', ''
    ) RETURNING id INTO demo_user_id;

    INSERT INTO user_profiles (id, full_name, phone, role)
    VALUES (demo_user_id, 'Demo User', '9876543210', 'user')
    ON CONFLICT (id) DO NOTHING;
  END IF;

  -- Check if admin user exists
  SELECT id INTO admin_user_id FROM auth.users WHERE email = 'admin@orionmall.com';
  IF admin_user_id IS NULL THEN
    INSERT INTO auth.users (
      instance_id, id, aud, role, email,
      encrypted_password, email_confirmed_at,
      raw_app_meta_data, raw_user_meta_data,
      created_at, updated_at, confirmation_token, recovery_token
    ) VALUES (
      '00000000-0000-0000-0000-000000000000',
      gen_random_uuid(), 'authenticated', 'authenticated',
      'admin@orionmall.com',
      crypt('Admin@1234', gen_salt('bf')),
      now(),
      '{"provider": "email", "providers": ["email"], "role": "admin"}',
      '{"full_name": "Admin User"}',
      now(), now(), '', ''
    ) RETURNING id INTO admin_user_id;

    INSERT INTO user_profiles (id, full_name, phone, role)
    VALUES (admin_user_id, 'Mall Admin', '9900000001', 'admin')
    ON CONFLICT (id) DO NOTHING;
  END IF;
END $$;

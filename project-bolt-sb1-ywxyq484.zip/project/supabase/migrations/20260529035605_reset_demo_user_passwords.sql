/*
  # Reset demo user passwords
  
  Updates the password hashes for demo users to use bcrypt format
  compatible with Supabase Auth's GoTrue engine.
  
  Passwords:
  - demo@orionmall.com: Demo@1234
  - admin@orionmall.com: Admin@1234
*/

-- Update password hashes using pgcrypto's crypt with blowfish
-- GoTrue uses bcrypt with cost 10
UPDATE auth.users
SET encrypted_password = crypt('Demo@1234', gen_salt('bf', 10))
WHERE email = 'demo@orionmall.com';

UPDATE auth.users
SET encrypted_password = crypt('Admin@1234', gen_salt('bf', 10))
WHERE email = 'admin@orionmall.com';

-- Ensure email is confirmed
UPDATE auth.users
SET email_confirmed_at = now(),
    updated_at = now()
WHERE email IN ('demo@orionmall.com', 'admin@orionmall.com')
  AND email_confirmed_at IS NULL;

-- Ensure user_profiles exist
INSERT INTO public.user_profiles (id, full_name, phone, role)
SELECT id, 'Demo User', '9876543210', 'user'
FROM auth.users WHERE email = 'demo@orionmall.com'
ON CONFLICT (id) DO UPDATE SET role = 'user', full_name = 'Demo User';

INSERT INTO public.user_profiles (id, full_name, phone, role)
SELECT id, 'Admin User', '9876543211', 'admin'
FROM auth.users WHERE email = 'admin@orionmall.com'
ON CONFLICT (id) DO UPDATE SET role = 'admin', full_name = 'Admin User';

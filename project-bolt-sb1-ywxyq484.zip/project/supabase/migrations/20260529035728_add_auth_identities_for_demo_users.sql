/*
  # Add auth identities for demo users
  
  Supabase GoTrue requires an entry in auth.identities for each user
  to authenticate via email/password. The provider_id for email provider
  should be the email address itself.
*/

INSERT INTO auth.identities (id, user_id, provider_id, identity_data, provider, last_sign_in_at, created_at, updated_at)
SELECT
  gen_random_uuid(),
  id,
  email,
  jsonb_build_object('sub', id::text, 'email', email),
  'email',
  now(),
  now(),
  now()
FROM auth.users
WHERE email IN ('demo@orionmall.com', 'admin@orionmall.com')
ON CONFLICT DO NOTHING;

/*
  # Smart Parking Management System - Orion Mall Bangalore

  ## Overview
  Complete schema for a smart parking management system with real-time slot tracking,
  bookings, payments, penalties, and notifications.

  ## Tables Created
  1. `parking_floors` - Floor definitions (B1, B2, Ground, VIP)
  2. `parking_slots` - Individual slot records with status
  3. `vehicles` - User vehicles registered in system
  4. `bookings` - Parking reservations and active sessions
  5. `payments` - Payment records linked to bookings
  6. `notifications` - User notification messages
  7. `penalties` - Overstay penalty records

  ## Security
  - RLS enabled on all tables
  - Authenticated users can access their own data
  - Admin role via app_metadata check
*/

-- Parking Floors
CREATE TABLE IF NOT EXISTS parking_floors (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  floor_code text UNIQUE NOT NULL,
  floor_name text NOT NULL,
  total_slots integer NOT NULL DEFAULT 0,
  description text DEFAULT '',
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE parking_floors ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view floors"
  ON parking_floors FOR SELECT
  TO authenticated
  USING (true);

-- Parking Slots
CREATE TABLE IF NOT EXISTS parking_slots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  floor_id uuid NOT NULL REFERENCES parking_floors(id) ON DELETE CASCADE,
  slot_number text NOT NULL,
  slot_type text NOT NULL DEFAULT 'regular' CHECK (slot_type IN ('regular', 'vip', 'handicapped', 'ev')),
  status text NOT NULL DEFAULT 'available' CHECK (status IN ('available', 'occupied', 'reserved', 'not_available')),
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  UNIQUE(floor_id, slot_number)
);

ALTER TABLE parking_slots ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view slots"
  ON parking_slots FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated can update slots"
  ON parking_slots FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Vehicles
CREATE TABLE IF NOT EXISTS vehicles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  vehicle_number text NOT NULL,
  vehicle_type text NOT NULL DEFAULT 'car' CHECK (vehicle_type IN ('car', 'bike', 'suv', 'truck')),
  brand text DEFAULT '',
  model text DEFAULT '',
  color text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, vehicle_number)
);

ALTER TABLE vehicles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own vehicles"
  ON vehicles FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own vehicles"
  ON vehicles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own vehicles"
  ON vehicles FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can view all vehicles"
  ON vehicles FOR SELECT
  TO authenticated
  USING ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

-- Bookings
CREATE TABLE IF NOT EXISTS bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  slot_id uuid NOT NULL REFERENCES parking_slots(id),
  vehicle_id uuid REFERENCES vehicles(id),
  vehicle_number text NOT NULL,
  status text NOT NULL DEFAULT 'reserved' CHECK (status IN ('reserved', 'active', 'completed', 'cancelled')),
  booked_duration_hours numeric NOT NULL DEFAULT 2,
  entry_time timestamptz,
  exit_time timestamptz,
  expected_exit_time timestamptz,
  base_rate numeric NOT NULL DEFAULT 50,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own bookings"
  ON bookings FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own bookings"
  ON bookings FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own bookings"
  ON bookings FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can view all bookings"
  ON bookings FOR SELECT
  TO authenticated
  USING ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

CREATE POLICY "Admins can update all bookings"
  ON bookings FOR UPDATE
  TO authenticated
  USING ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin')
  WITH CHECK ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

-- Payments
CREATE TABLE IF NOT EXISTS payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id uuid NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id),
  base_amount numeric NOT NULL DEFAULT 0,
  extra_time_amount numeric NOT NULL DEFAULT 0,
  penalty_amount numeric NOT NULL DEFAULT 0,
  total_amount numeric NOT NULL DEFAULT 0,
  payment_method text DEFAULT 'online' CHECK (payment_method IN ('online', 'cash', 'upi', 'card')),
  payment_status text NOT NULL DEFAULT 'pending' CHECK (payment_status IN ('pending', 'completed', 'failed', 'refunded')),
  transaction_id text DEFAULT '',
  paid_at timestamptz,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE payments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own payments"
  ON payments FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own payments"
  ON payments FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own payments"
  ON payments FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can view all payments"
  ON payments FOR SELECT
  TO authenticated
  USING ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

-- Notifications
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  booking_id uuid REFERENCES bookings(id),
  title text NOT NULL,
  message text NOT NULL,
  type text NOT NULL DEFAULT 'info' CHECK (type IN ('info', 'warning', 'penalty', 'success', 'alert')),
  is_read boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own notifications"
  ON notifications FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own notifications"
  ON notifications FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can insert notifications"
  ON notifications FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can insert notifications"
  ON notifications FOR INSERT
  TO authenticated
  WITH CHECK ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

-- Penalties
CREATE TABLE IF NOT EXISTS penalties (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id uuid NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id),
  overstay_minutes integer NOT NULL DEFAULT 0,
  penalty_amount numeric NOT NULL DEFAULT 0,
  reason text DEFAULT 'Overstay',
  is_paid boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE penalties ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own penalties"
  ON penalties FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own penalties"
  ON penalties FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own penalties"
  ON penalties FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Admins can view all penalties"
  ON penalties FOR SELECT
  TO authenticated
  USING ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

-- User Profiles (extended info)
CREATE TABLE IF NOT EXISTS user_profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text DEFAULT '',
  phone text DEFAULT '',
  role text DEFAULT 'user' CHECK (role IN ('user', 'admin', 'operator')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own profile"
  ON user_profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON user_profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON user_profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Admins can view all profiles"
  ON user_profiles FOR SELECT
  TO authenticated
  USING ((auth.jwt() -> 'app_metadata' ->> 'role') = 'admin');

-- Seed Parking Floors
INSERT INTO parking_floors (floor_code, floor_name, total_slots, description, is_active)
VALUES
  ('B1', 'Basement B1', 80, 'Underground parking level 1 - Regular vehicles', true),
  ('B2', 'Basement B2', 80, 'Underground parking level 2 - Regular vehicles', true),
  ('GF', 'Ground Floor', 60, 'Ground level open parking - All vehicles', true),
  ('VIP', 'VIP Parking', 20, 'Premium VIP and luxury vehicle parking', true)
ON CONFLICT DO NOTHING;

-- Seed Parking Slots for B1
DO $$
DECLARE
  b1_id uuid;
  b2_id uuid;
  gf_id uuid;
  vip_id uuid;
  i integer;
  slot_status text;
  slot_type text;
BEGIN
  SELECT id INTO b1_id FROM parking_floors WHERE floor_code = 'B1';
  SELECT id INTO b2_id FROM parking_floors WHERE floor_code = 'B2';
  SELECT id INTO gf_id FROM parking_floors WHERE floor_code = 'GF';
  SELECT id INTO vip_id FROM parking_floors WHERE floor_code = 'VIP';

  -- B1 slots (80 slots: A01-A20, B01-B20, C01-C20, D01-D20)
  FOR i IN 1..20 LOOP
    IF i IN (5, 12, 18) THEN slot_status := 'not_available';
    ELSIF i IN (3, 7, 15) THEN slot_status := 'occupied';
    ELSIF i IN (2, 10) THEN slot_status := 'reserved';
    ELSE slot_status := 'available';
    END IF;
    INSERT INTO parking_slots (floor_id, slot_number, slot_type, status)
    VALUES (b1_id, 'A' || LPAD(i::text, 2, '0'), 'regular', slot_status)
    ON CONFLICT DO NOTHING;
  END LOOP;

  FOR i IN 1..20 LOOP
    IF i IN (4, 14) THEN slot_status := 'not_available';
    ELSIF i IN (1, 8, 16, 19) THEN slot_status := 'occupied';
    ELSIF i IN (5, 13) THEN slot_status := 'reserved';
    ELSE slot_status := 'available';
    END IF;
    INSERT INTO parking_slots (floor_id, slot_number, slot_type, status)
    VALUES (b1_id, 'B' || LPAD(i::text, 2, '0'), 'regular', slot_status)
    ON CONFLICT DO NOTHING;
  END LOOP;

  FOR i IN 1..20 LOOP
    IF i IN (9, 17) THEN slot_status := 'not_available';
    ELSIF i IN (2, 6, 11) THEN slot_status := 'occupied';
    ELSIF i IN (4, 14) THEN slot_status := 'reserved';
    ELSE slot_status := 'available';
    END IF;
    INSERT INTO parking_slots (floor_id, slot_number, slot_type, status)
    VALUES (b1_id, 'C' || LPAD(i::text, 2, '0'), 'regular', slot_status)
    ON CONFLICT DO NOTHING;
  END LOOP;

  FOR i IN 1..20 LOOP
    IF i IN (6, 13, 20) THEN slot_status := 'not_available';
    ELSIF i IN (3, 9, 15) THEN slot_status := 'occupied';
    ELSIF i IN (7, 17) THEN slot_status := 'reserved';
    ELSE slot_status := 'available';
    END IF;
    IF i <= 5 THEN slot_type := 'handicapped';
    ELSE slot_type := 'regular';
    END IF;
    INSERT INTO parking_slots (floor_id, slot_number, slot_type, status)
    VALUES (b1_id, 'D' || LPAD(i::text, 2, '0'), slot_type, slot_status)
    ON CONFLICT DO NOTHING;
  END LOOP;

  -- B2 slots
  FOR i IN 1..20 LOOP
    IF i IN (7, 15, 20) THEN slot_status := 'not_available';
    ELSIF i IN (2, 8, 14, 18) THEN slot_status := 'occupied';
    ELSIF i IN (6, 12) THEN slot_status := 'reserved';
    ELSE slot_status := 'available';
    END IF;
    INSERT INTO parking_slots (floor_id, slot_number, slot_type, status)
    VALUES (b2_id, 'A' || LPAD(i::text, 2, '0'), 'regular', slot_status)
    ON CONFLICT DO NOTHING;
  END LOOP;

  FOR i IN 1..20 LOOP
    IF i IN (3, 11) THEN slot_status := 'not_available';
    ELSIF i IN (5, 9, 17) THEN slot_status := 'occupied';
    ELSIF i IN (8, 15, 20) THEN slot_status := 'reserved';
    ELSE slot_status := 'available';
    END IF;
    INSERT INTO parking_slots (floor_id, slot_number, slot_type, status)
    VALUES (b2_id, 'B' || LPAD(i::text, 2, '0'), 'regular', slot_status)
    ON CONFLICT DO NOTHING;
  END LOOP;

  FOR i IN 1..20 LOOP
    IF i IN (10, 18) THEN slot_status := 'not_available';
    ELSIF i IN (1, 7, 13) THEN slot_status := 'occupied';
    ELSIF i IN (3, 16) THEN slot_status := 'reserved';
    ELSE slot_status := 'available';
    END IF;
    IF i <= 4 THEN slot_type := 'ev';
    ELSE slot_type := 'regular';
    END IF;
    INSERT INTO parking_slots (floor_id, slot_number, slot_type, status)
    VALUES (b2_id, 'C' || LPAD(i::text, 2, '0'), slot_type, slot_status)
    ON CONFLICT DO NOTHING;
  END LOOP;

  FOR i IN 1..20 LOOP
    IF i IN (5, 16) THEN slot_status := 'not_available';
    ELSIF i IN (4, 10, 19) THEN slot_status := 'occupied';
    ELSIF i IN (2, 13) THEN slot_status := 'reserved';
    ELSE slot_status := 'available';
    END IF;
    INSERT INTO parking_slots (floor_id, slot_number, slot_type, status)
    VALUES (b2_id, 'D' || LPAD(i::text, 2, '0'), 'regular', slot_status)
    ON CONFLICT DO NOTHING;
  END LOOP;

  -- Ground Floor slots (60 slots: R01-R20, S01-S20, T01-T20)
  FOR i IN 1..20 LOOP
    IF i IN (8, 16) THEN slot_status := 'not_available';
    ELSIF i IN (3, 9, 15, 20) THEN slot_status := 'occupied';
    ELSIF i IN (5, 12) THEN slot_status := 'reserved';
    ELSE slot_status := 'available';
    END IF;
    INSERT INTO parking_slots (floor_id, slot_number, slot_type, status)
    VALUES (gf_id, 'R' || LPAD(i::text, 2, '0'), 'regular', slot_status)
    ON CONFLICT DO NOTHING;
  END LOOP;

  FOR i IN 1..20 LOOP
    IF i IN (4, 14, 19) THEN slot_status := 'not_available';
    ELSIF i IN (2, 7, 13, 18) THEN slot_status := 'occupied';
    ELSIF i IN (9, 16) THEN slot_status := 'reserved';
    ELSE slot_status := 'available';
    END IF;
    IF i <= 5 THEN slot_type := 'handicapped';
    ELSE slot_type := 'regular';
    END IF;
    INSERT INTO parking_slots (floor_id, slot_number, slot_type, status)
    VALUES (gf_id, 'S' || LPAD(i::text, 2, '0'), slot_type, slot_status)
    ON CONFLICT DO NOTHING;
  END LOOP;

  FOR i IN 1..20 LOOP
    IF i IN (11, 20) THEN slot_status := 'not_available';
    ELSIF i IN (4, 8, 16) THEN slot_status := 'occupied';
    ELSIF i IN (3, 14) THEN slot_status := 'reserved';
    ELSE slot_status := 'available';
    END IF;
    IF i <= 6 THEN slot_type := 'ev';
    ELSE slot_type := 'regular';
    END IF;
    INSERT INTO parking_slots (floor_id, slot_number, slot_type, status)
    VALUES (gf_id, 'T' || LPAD(i::text, 2, '0'), slot_type, slot_status)
    ON CONFLICT DO NOTHING;
  END LOOP;

  -- VIP slots (20 slots: V01-V20)
  FOR i IN 1..20 LOOP
    IF i IN (8, 15) THEN slot_status := 'not_available';
    ELSIF i IN (1, 4, 9, 14, 19) THEN slot_status := 'occupied';
    ELSIF i IN (3, 12) THEN slot_status := 'reserved';
    ELSE slot_status := 'available';
    END IF;
    INSERT INTO parking_slots (floor_id, slot_number, slot_type, status)
    VALUES (vip_id, 'V' || LPAD(i::text, 2, '0'), 'vip', slot_status)
    ON CONFLICT DO NOTHING;
  END LOOP;

END $$;

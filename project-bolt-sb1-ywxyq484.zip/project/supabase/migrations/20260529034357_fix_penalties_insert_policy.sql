/*
  # Fix penalties insert policy to allow application-level inserts

  The penalty system inserts penalties when processing vehicle exits.
  Allow any authenticated user to insert penalties (booking owner records their own).
*/

DROP POLICY IF EXISTS "Users can insert own penalties" ON penalties;

CREATE POLICY "Authenticated can insert penalties"
  ON penalties FOR INSERT
  TO authenticated
  WITH CHECK (true);

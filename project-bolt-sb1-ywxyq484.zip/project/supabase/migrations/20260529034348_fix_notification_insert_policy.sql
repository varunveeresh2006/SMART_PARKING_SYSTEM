/*
  # Fix notification insert policy to allow system inserts
  Allow any authenticated user to insert notifications (needed for penalty system
  where a user's exit triggers notifications for themselves)
*/

-- Drop the conflicting insert policies and replace with a single one
DROP POLICY IF EXISTS "Users can insert notifications" ON notifications;
DROP POLICY IF EXISTS "Admins can insert notifications" ON notifications;

-- Allow any authenticated user to insert notifications for any user_id
-- (The application logic ensures only valid notifications are inserted)
CREATE POLICY "Authenticated can insert notifications"
  ON notifications FOR INSERT
  TO authenticated
  WITH CHECK (true);

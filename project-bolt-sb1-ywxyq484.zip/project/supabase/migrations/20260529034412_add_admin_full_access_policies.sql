/*
  # Add Admin Full Access Policies

  Admins (role = 'admin' in user_profiles) need to view all records
  across all tables for the admin dashboard and database viewer.
  
  Uses a helper function to check admin status via user_profiles table.
*/

-- Helper function to check if current user is admin
CREATE OR REPLACE FUNCTION is_admin()
RETURNS boolean AS $$
  SELECT EXISTS (
    SELECT 1 FROM user_profiles
    WHERE id = auth.uid() AND role = 'admin'
  );
$$ LANGUAGE sql SECURITY DEFINER STABLE;

-- Admin view policies for all tables
CREATE POLICY "Admins can view all vehicles via profile"
  ON vehicles FOR SELECT
  TO authenticated
  USING (is_admin());

CREATE POLICY "Admins can view all bookings via profile"
  ON bookings FOR SELECT
  TO authenticated
  USING (is_admin());

CREATE POLICY "Admins can update all bookings via profile"
  ON bookings FOR UPDATE
  TO authenticated
  USING (is_admin())
  WITH CHECK (is_admin());

CREATE POLICY "Admins can view all payments via profile"
  ON payments FOR SELECT
  TO authenticated
  USING (is_admin());

CREATE POLICY "Admins can view all penalties via profile"
  ON penalties FOR SELECT
  TO authenticated
  USING (is_admin());

CREATE POLICY "Admins can view all notifications via profile"
  ON notifications FOR SELECT
  TO authenticated
  USING (is_admin());

CREATE POLICY "Admins can view all user profiles"
  ON user_profiles FOR SELECT
  TO authenticated
  USING (is_admin());

-- Admin can update any slot status
CREATE POLICY "Admins can update slot status"
  ON parking_slots FOR UPDATE
  TO authenticated
  USING (is_admin())
  WITH CHECK (is_admin());
